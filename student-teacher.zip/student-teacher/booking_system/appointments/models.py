# Create your models here.
from django.contrib.auth.models import User
from django.db import models

# Teacher model extending user for profile info
class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    specialization = models.CharField(max_length=100)
    def __str__(self):
        return self.user.username 

# Student model extending user for profile info
class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    age = models.IntegerField()
    def __str__(self):
        return self.user.username 


# Appointment model for booking info
class Appointment(models.Model):
    teacher = models.ForeignKey(Teacher,on_delete=models.CASCADE)
    student = models.ForeignKey(Student,on_delete=models.CASCADE)
    date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')])

    def __str__(self):
        return f"{self.student.user.username} with {self.teacher.user.username} on {self.date}"
