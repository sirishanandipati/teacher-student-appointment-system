
# Create your views here.
from django.shortcuts import render, redirect
from .models import Teacher, Student, Appointment
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Redirect based on user role
            if hasattr(user, 'teacher'):
                return redirect('dashboard')
            elif hasattr(user, 'student'):
                return redirect('dashboard')
            else:
                return redirect('admin:index')  # Admin dashboard
        else:
            return render(request, 'appointments/login.html', {'error': 'Invalid credentials'})

    return render(request, 'appointments/login.html')

def register(request, role):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = User.objects.create_user(username=username, password=password)
        if role == 'teacher':
           specialization = request.POST['specialization']
           Teacher.objects.create(user=user, specialization=specialization)
        elif role == 'student':
            age = request.POST['age']
            Student.objects.create(user=user, age=age)
        return redirect('login')
    return render(request, 'appointments/register.html', {'role': role})

# View for booking an appointment
@login_required
def book_appointment(request, teacher_id):
    if request.method == 'POST':
        student = Student.objects.get(user=request.user)
        teacher = Teacher.objects.get(id=teacher_id)
        date = request.POST['date']
        Appointment.objects.create(student=student, teacher=teacher, date=date, status='pending')
        return redirect('dashboard')
    return render(request, 'appointments/book_appointment.html', {'teacher_id': teacher_id})

# Dashboard view for viewing appointments
@login_required

def dashboard(request):
     # Initialize an empty query set
    appointments = Appointment.objects.none()

     # If the user is a teacher, show their appointments
    if hasattr(request.user, 'teacher'):
         appointments = Appointment.objects.filter(teacher=request.user.teacher)

    # If the user is a student, show their appointments
    elif hasattr(request.user, 'student'):
        appointments = Appointment.objects.filter(student=request.user.student)

    # If the user is admin, show all appointments
    elif request.user.is_superuser:
        appointments = Appointment.objects.all()

    return render(request, 'appointments/dashboard.html', {
        'appointments': appointments,
    })
from appointments.models import Appointment

#Fetch all appointments
appointments = Appointment.objects.all()
for appointment in appointments:
     print(f"Student: {appointment.student.user.username}, Teacher: {appointment.teacher.user.username}, Date: {appointment.date}, Status: {appointment.status}")







